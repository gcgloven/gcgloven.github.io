import * as THREE from './vendor/three.module.min.js';

export const PALETTE = {
  ink: 0x242925,
  stone: 0xb6bbb0,
  paper: 0xf4f2e7,
  slab: 0xcdd0c4,
  edge: 0x8f9889,
  red: 0xe7462b,
  darkRed: 0x9f3024,
};

export const FIELD_THEME = Object.freeze({
  maxPixelRatio: 1.6,
  exposure: 1.0,
  materialRoughness: 0.88,
  metalness: { ink: 0.15, default: 0.02 },
  travel: { speed: 6, minimumSeconds: 0.65, maximumSeconds: 1.75 },
  avatarScale: { desktop: 1.4, mobile: 1.9 },
});

/** One shared material set per field; the field owns disposal. */
export function createFieldMaterials() {
  const materials = Object.fromEntries(Object.entries(PALETTE).map(([name, color]) => [name,
    new THREE.MeshStandardMaterial({ color, roughness: FIELD_THEME.materialRoughness, metalness: FIELD_THEME.metalness[name] ?? FIELD_THEME.metalness.default }),
  ]));
  return materials;
}

/** All models share this warm daylight rig. No model should add its own lights. */
export function addFieldLighting(scene) {
  scene.add(new THREE.HemisphereLight(0xfff9e9, 0x7c897c, 2.0));
  const sunlight = new THREE.DirectionalLight(0xfff7df, 3.1);
  sunlight.position.set(-8, 19, 9);
  sunlight.castShadow = true;
  sunlight.shadow.mapSize.set(1024, 1024);
  sunlight.shadow.camera.left = -15;
  sunlight.shadow.camera.right = 15;
  sunlight.shadow.camera.top = 14;
  sunlight.shadow.camera.bottom = -14;
  sunlight.shadow.camera.near = 1;
  sunlight.shadow.camera.far = 50;
  sunlight.shadow.normalBias = 0.04;
  sunlight.shadow.bias = -0.0003;
  scene.add(sunlight);

  return { sunlight };
}
