import * as THREE from './vendor/three.module.min.js';

// Builders receive shared geometry/material helpers. The engine owns all disposal.
// Add a matching key to model-catalog.json when registering a new builder here.
const builders = {
  // 01 / A brutalist apartment block whose slabs separate when approached.
  building({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    const floors = [];
    for (let i = 0; i < 3; i++) {
      const floor = new THREE.Group();
      floor.position.y = 0.24 + i * 1.05;
      sculpture.add(floor);
      box(floor, i === 1 ? 'ink' : 'paper', 0, 0.13, 0, 3.35, 0.23, 2.55);
      box(floor, 'stone', 0, 0.87, 0, 3.35, 0.18, 2.55);
      box(floor, i === 1 ? 'paper' : 'stone', -1.41, 0.5, 0, 0.28, 0.66, 2.3);
      box(floor, 'ink', 1.35, 0.5, -0.55, 0.25, 0.66, 1.3);
      box(floor, 'stone', 0, 0.5, -1.06, 2.65, 0.66, 0.2);
      for (const x of [-0.7, 0.25, 1.04]) box(floor, 'ink', x, 0.5, 1.06, 0.1, 0.66, 0.1);
      floors.push(floor);
    }
    const rooftop = new THREE.Group();
    sculpture.add(rooftop);
    box(rooftop, 'red', 1.12, 3.67, -0.61, 0.53, 0.68, 0.55);
    box(rooftop, 'paper', -0.69, 3.49, -0.12, 1.3, 0.3, 1.05);
    animate = ((time, hover) => {
      floors.forEach((floor, i) => {
        floor.position.y = 0.24 + i * 1.05 + hover * i * 0.22;
        floor.position.x = hover * (i - 1) * 0.18;
      });
      rooftop.position.y = hover * 0.66;
    });
    return { animate };
  },

  // 02 / A broadcast mast: the dish follows the visitor, its flag answers the wind.
  dish({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    for (const x of [-0.6, 0.6]) for (const z of [-0.45, 0.45]) {
      rod(sculpture, [x, 0.25, z], [x * 0.44, 3.5, z * 0.44], 0.055);
    }
    for (let i = 0; i < 4; i++) {
      const y = 0.3 + i * 0.72;
      const span = 0.58 - i * 0.075;
      rod(sculpture, [-span, y, 0.45 - i * 0.045], [span - 0.04, y + 0.65, 0.42 - i * 0.045], 0.035);
      rod(sculpture, [span, y, -0.45 + i * 0.045], [-span + 0.04, y + 0.65, -0.42 + i * 0.045], 0.035);
    }
    const dish = new THREE.Group();
    dish.position.set(0, 3.13, 0);
    sculpture.add(dish);
    const dishGeometry = ownGeometry(new THREE.LatheGeometry([
      new THREE.Vector2(0.05, 0), new THREE.Vector2(0.27, 0.04),
      new THREE.Vector2(0.62, 0.22), new THREE.Vector2(0.95, 0.54),
    ], 24));
    const dishMaterial = materials.paper.clone();
    dishMaterial.side = THREE.DoubleSide;
    const bowl = mesh(dishGeometry, dishMaterial, dish);
    bowl.rotation.x = Math.PI * 0.23;
    bowl.rotation.z = -0.32;
    rod(dish, [0, 0, 0], [0.2, 1.06, 0.51], 0.035, 'red');
    mesh(ownGeometry(new THREE.SphereGeometry(0.12, 10, 8)), 'red', dish, 0.2, 1.06, 0.51);
    box(sculpture, 'red', -0.67, 0.63, 0.08, 0.68, 0.73, 0.6);
    box(sculpture, 'paper', -0.67, 0.71, 0.39, 0.42, 0.22, 0.025);
    animate = ((time, hover, motion) => { dish.rotation.y = motion ? Math.sin(time * 0.25) * 0.24 + hover * 0.35 : 0; });
    return { animate };
  },

  // 07 / A massive threshold frames a suspended, red sun.
  portal({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    box(sculpture, 'ink', -1.13, 2.0, 0, 0.5, 3.5, 0.83);
    box(sculpture, 'ink', 1.13, 2.0, 0, 0.5, 3.5, 0.83);
    box(sculpture, 'ink', 0, 3.76, 0, 2.77, 0.5, 0.83);
    box(sculpture, 'paper', 0, 0.45, 0.18, 2.24, 0.21, 1.9);
    box(sculpture, 'stone', 0, 0.35, 0.57, 2.7, 0.2, 1.6);
    const moon = mesh(ownGeometry(new THREE.SphereGeometry(0.54, 24, 16)), 'red', sculpture, 0, 2.4, 0.0);
    const horizon = box(sculpture, 'red', 0, 1.24, -0.05, 1.75, 0.038, 0.065);
    animate = ((time, hover, motion) => {
      moon.position.y = 2.4 + (motion ? Math.sin(time * 0.65) * 0.13 : 0) + hover * 0.2;
      horizon.scale.x = 1.75 + hover * 0.32;
    });
    return { animate };
  },

  // 04 / Open pages become an architectural fan, supported by a carbon spine.
  book({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    box(sculpture, 'ink', 0, 0.76, 0.0, 0.27, 1.05, 1.65);
    const leaves = [];
    for (let i = 0; i < 7; i++) {
      const page = new THREE.Group();
      page.position.set(0, 0.9, 0);
      const angle = (i - 3) * 0.24;
      page.rotation.z = angle;
      sculpture.add(page);
      box(page, i === 0 ? 'red' : 'paper', 0, 0.91, 0, 0.065, 2.1, 1.7);
      if (i === 6) {
        for (let row = 0; row < 5; row++) box(page, 'ink', 0.038, 0.48 + row * 0.24, 0, 0.012, 0.024, 1.22 - row * 0.09);
      }
      leaves.push({ page, angle });
    }
    animate = ((time, hover) => leaves.forEach(({ page, angle }, i) => { page.rotation.z = angle * (1 + hover * 0.42); }));
    return { animate };
  },

  // 03 / A kinetic gyroscope: two moving rings and a solid core, not an icon.
  gyroscope({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    cylinder(sculpture, 'ink', 0, 0.45, 0, 1.25, 0.42);
    cylinder(sculpture, 'stone', 0, 0.7, 0, 1.08, 0.12);
    box(sculpture, 'ink', -1.38, 1.37, 0, 0.23, 2.1, 0.46);
    box(sculpture, 'ink', 1.38, 1.37, 0, 0.23, 2.1, 0.46);
    const pivot = new THREE.Group();
    pivot.position.y = 2.0;
    sculpture.add(pivot);
    const outer = mesh(ownGeometry(new THREE.TorusGeometry(1.36, 0.1, 8, 48)), 'red', pivot);
    const inner = mesh(ownGeometry(new THREE.TorusGeometry(1.04, 0.07, 8, 40)), 'ink', pivot);
    inner.rotation.x = Math.PI / 2;
    const core = mesh(ownGeometry(new THREE.OctahedronGeometry(0.55)), 'paper', pivot);
    rod(sculpture, [-1.52, 2.0, 0], [1.52, 2.0, 0], 0.055, 'paper');
    animate = ((time, hover, motion) => {
      outer.rotation.y = motion ? time * 0.32 + hover * 0.5 : 0.4;
      outer.rotation.x = 0.15;
      inner.rotation.y = motion ? -time * 0.48 : -0.35;
      core.rotation.y = motion ? time * 0.2 : 0;
      pivot.rotation.z = hover * 0.12;
    });
    return { animate };
  },

  // 06 / A staircase whose final flight walks out into open air.
  stairs({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    for (let i = 0; i < 9; i++) {
      const y = 0.42 + i * 0.34;
      const z = 1.02 - i * 0.27;
      box(sculpture, i > 5 ? 'ink' : 'stone', 0, y, z, 1.8, 0.25, 0.55);
      if (i < 6) box(sculpture, 'stone', 0.52, y / 2 + 0.09, z, 0.22, y - 0.12, 0.25);
    }
    box(sculpture, 'red', 0, 3.46, -1.29, 2.34, 0.3, 0.62);
    rod(sculpture, [-0.98, 0.57, 1.06], [-0.98, 3.44, -1.28], 0.034);
    rod(sculpture, [-0.98, 0.57, 1.06], [-0.98, 1.05, 1.06], 0.034);
    rod(sculpture, [-0.98, 1.05, 1.06], [-0.98, 3.96, -1.28], 0.034);
    rod(sculpture, [-0.98, 3.44, -1.28], [-0.98, 3.96, -1.28], 0.034);
    animate = (() => {});
    return { animate };
  },

  // 05 / Reusable fragments: a precarious stack of unreasonably heavy blocks.
  fragments({ sculpture, box, cylinder, rod, mesh, ownGeometry, materials }) {
    let animate = () => {};
    const blocks = [];
    const definitions = [
      [-0.25, 0.57, 0, 2.45, 0.62, 1.63, 'ink', -0.05],
      [0.21, 1.18, 0.03, 1.94, 0.47, 1.43, 'red', 0.18],
      [-0.38, 1.71, -0.05, 2.2, 0.43, 1.2, 'paper', -0.22],
      [0.18, 2.2, 0, 1.45, 0.43, 1.06, 'red', 0.28],
    ];
    for (const [x, y, z, width, height, depth, material, angle] of definitions) {
      const block = box(sculpture, material, x, y, z, width, height, depth);
      block.rotation.y = angle;
      blocks.push({ block, y, angle });
    }
    animate = ((time, hover, motion) => blocks.forEach(({ block, y, angle }, i) => {
      block.position.y = y + hover * i * 0.11;
      block.rotation.y = angle + (motion ? Math.sin(time * 0.65 + i * 0.7) * 0.035 : 0) + hover * i * 0.06;
    }));
    return { animate };
  },

};

export const MODEL_KEYS = Object.freeze(Object.keys(builders));

/** Build a sculpture inside the supplied group. Collection IDs never enter a model. */
export function buildLandmark(model, context) {
  const builder = builders[model];
  if (!builder) throw new Error(`Unknown landmark model: ${model}`);
  return builder(context);
}
