import * as THREE from './vendor/three.module.min.js';

/** Small, articulated companions. Every rig owns its geometry and materials. */
export function createAvatarRig(kind = 'fox') {
  const group = new THREE.Group();
  group.name = `companion-${kind}`;
  const body = new THREE.Group();
  group.add(body);

  const materials = {
    ink: new THREE.MeshStandardMaterial({ color: 0x272923, roughness: 0.86, flatShading: true }),
    cream: new THREE.MeshStandardMaterial({ color: 0xf1e9d3, roughness: 0.86, flatShading: true }),
    red: new THREE.MeshStandardMaterial({ color: 0xbc432c, roughness: 0.8, flatShading: true }),
    orange: new THREE.MeshStandardMaterial({ color: 0xd36132, roughness: 0.78, flatShading: true }),
    olive: new THREE.MeshStandardMaterial({ color: 0x69704b, roughness: 0.92, flatShading: true, side: THREE.DoubleSide }),
    leaf: new THREE.MeshStandardMaterial({ color: 0x92966d, roughness: 0.92, flatShading: true, side: THREE.DoubleSide }),
    steel: new THREE.MeshStandardMaterial({ color: 0x797f78, metalness: 0.62, roughness: 0.34, flatShading: true }),
  };

  const mesh = (geometry, material, parent = body, position = [0, 0, 0], scale) => {
    const object = new THREE.Mesh(geometry, materials[material] || material);
    object.position.set(...position);
    if (scale) object.scale.set(...scale);
    object.castShadow = true;
    object.receiveShadow = true;
    parent.add(object);
    return object;
  };
  const ball = (radius, material, parent, position, scale) =>
    mesh(new THREE.SphereGeometry(radius, 10, 7), material, parent, position, scale);
  const box = (size, material, parent, position) =>
    mesh(new THREE.BoxGeometry(...size), material, parent, position);
  const cylinder = (top, bottom, height, material, parent, position, sides = 10) =>
    mesh(new THREE.CylinderGeometry(top, bottom, height, sides), material, parent, position);
  const pivot = (parent, position) => {
    const object = new THREE.Group();
    object.position.set(...position);
    parent.add(object);
    return object;
  };

  let pose;

  if (kind === 'plant') {
    const pot = pivot(body, [0, 0.13, 0]);
    cylinder(0.235, 0.16, 0.34, 'red', pot, [0, 0.21, 0]);
    cylinder(0.255, 0.255, 0.075, 'red', pot, [0, 0.39, 0]);
    cylinder(0.21, 0.21, 0.026, 'ink', pot, [0, 0.433, 0]);
    // Small inset eyes give the otherwise architectural pot an expressive front.
    for (const side of [-1, 1]) {
      ball(0.028, 'cream', pot, [side * 0.077, 0.24, 0.21], [1, 1.3, 0.48]);
      ball(0.012, 'ink', pot, [side * 0.077, 0.241, 0.223], [1, 1.2, 0.6]);
    }
    const stem = pivot(pot, [0, 0.435, 0]);
    cylinder(0.018, 0.027, 0.42, 'olive', stem, [0, 0.21, 0]);
    const leaves = [];
    function leaf(length, width, height, angle, lean, material) {
      const attachment = pivot(stem, [0, height, 0]);
      attachment.rotation.y = angle;
      attachment.rotation.z = lean;
      const geometry = new THREE.BufferGeometry();
      // A folded, pointed leaf, with a raised central vein and a curled tip.
      geometry.setAttribute('position', new THREE.Float32BufferAttribute([
        0, 0, 0, -width, length * 0.45, 0, 0, length * 0.48, 0.07,
        0, 0, 0, 0, length * 0.48, 0.07, width, length * 0.45, 0,
        -width, length * 0.45, 0, 0, length, -0.055, 0, length * 0.48, 0.07,
        0, length * 0.48, 0.07, 0, length, -0.055, width, length * 0.45, 0,
      ], 3));
      geometry.computeVertexNormals();
      mesh(geometry, material, attachment);
      leaves.push({ object: attachment, lean, angle });
    }
    leaf(0.34, 0.125, 0.12, 0.3, -0.9, 'olive');
    leaf(0.33, 0.13, 0.17, -0.15, 0.9, 'leaf');
    leaf(0.26, 0.10, 0.27, 1.9, -0.72, 'olive');
    leaf(0.28, 0.105, 0.32, 0.3, -0.26, 'leaf');
    const feet = [-1, 1].map(side => {
      const foot = pivot(body, [side * 0.105, 0.065, 0.018]);
      ball(0.105, 'ink', foot, [0, 0, 0.06], [0.8, 0.58, 1.45]);
      return foot;
    });
    pose = (t, stride) => {
      const cycle = t * 11;
      pot.position.y = 0.13 + Math.abs(Math.sin(cycle)) * 0.045 * stride;
      pot.rotation.z = Math.sin(cycle) * 0.075 * stride;
      stem.rotation.z = Math.sin(t * 2.3) * 0.025 + Math.sin(cycle - 0.45) * 0.10 * stride;
      leaves.forEach(({ object, lean, angle }, index) => {
        object.rotation.z = lean + Math.sin(t * 2.6 + index * 0.9) * 0.035 + Math.cos(cycle - index * 0.4) * stride * 0.06;
        object.rotation.y = angle + Math.sin(t * 1.5 + index) * 0.035;
      });
      feet.forEach((foot, index) => {
        const step = Math.sin(cycle + index * Math.PI);
        foot.position.y = 0.065 + Math.max(0, step) * stride * 0.09;
        foot.position.z = 0.018 + Math.cos(cycle + index * Math.PI) * stride * 0.08;
      });
    };
  } else if (kind === 'duck') {
    const torso = pivot(body, [0, 0.37, 0]);
    ball(0.295, 'cream', torso, [0, 0, -0.04], [0.86, 0.91, 1.22]);
    cylinder(0.115, 0.145, 0.26, 'cream', torso, [0, 0.20, 0.14]);
    const head = pivot(torso, [0, 0.37, 0.20]);
    ball(0.177, 'cream', head, [0, 0, 0], [1, 1.03, 1]);
    const beak = box([0.21, 0.064, 0.20], 'orange', head, [0, -0.025, 0.20]);
    beak.rotation.x = 0.07;
    box([0.192, 0.011, 0.135], 'red', head, [0, -0.04, 0.235]);
    for (const side of [-1, 1]) {
      ball(0.023, 'ink', head, [side * 0.125, 0.048, 0.106], [0.72, 1.0, 0.8]);
    }
    const wings = [-1, 1].map(side => {
      const wing = pivot(torso, [side * 0.22, 0.01, -0.055]);
      ball(0.16, 'cream', wing, [0, 0, 0], [0.27, 0.88, 1.35]);
      wing.rotation.z = side * 0.14;
      return wing;
    });
    const tail = mesh(new THREE.ConeGeometry(0.10, 0.22, 5), 'cream', torso, [0, 0.04, -0.36]);
    tail.rotation.x = -1.04;
    const feet = [-1, 1].map(side => {
      const foot = pivot(body, [side * 0.12, 0.049, 0.048]);
      const shape = new THREE.Shape();
      shape.moveTo(-0.045, -0.055);
      shape.lineTo(-0.085, 0.125);
      shape.lineTo(-0.025, 0.10);
      shape.lineTo(0, 0.145);
      shape.lineTo(0.035, 0.105);
      shape.lineTo(0.082, 0.13);
      shape.lineTo(0.045, -0.055);
      shape.closePath();
      const web = mesh(new THREE.ExtrudeGeometry(shape, { depth: 0.035, bevelEnabled: false }), 'orange', foot);
      web.rotation.x = Math.PI / 2;
      cylinder(0.025, 0.032, 0.12, 'orange', foot, [0, 0.065, 0]);
      return foot;
    });
    pose = (t, stride) => {
      const cycle = t * 12;
      torso.position.y = 0.37 + Math.abs(Math.sin(cycle)) * 0.035 * stride;
      torso.rotation.z = Math.sin(cycle) * 0.11 * stride;
      torso.rotation.x = 0.045 * stride;
      head.rotation.y = Math.sin(t * 1.15) * 0.085 * (1 - stride * 0.7);
      wings.forEach((wing, index) => {
        wing.rotation.z = (index ? 1 : -1) * (0.14 + Math.abs(Math.sin(cycle)) * 0.10 * stride);
      });
      feet.forEach((foot, index) => {
        const step = Math.sin(cycle + index * Math.PI);
        foot.position.y = 0.049 + Math.max(0, step) * stride * 0.11;
        foot.position.z = 0.048 + Math.cos(cycle + index * Math.PI) * stride * 0.09;
        foot.rotation.x = -Math.max(0, step) * stride * 0.3;
      });
    };
  } else if (kind === 'spring') {
    const base = pivot(body, [0, 0.055, 0]);
    cylinder(0.235, 0.26, 0.09, 'ink', base, [0, 0, 0]);
    cylinder(0.20, 0.20, 0.035, 'red', base, [0, 0.064, 0]);
    const coilGroup = pivot(body, [0, 0.14, 0]);
    const points = [];
    for (let step = 0; step <= 144; step += 1) {
      const fraction = step / 144;
      const angle = fraction * Math.PI * 2 * 4.5;
      points.push(new THREE.Vector3(Math.cos(angle) * 0.18, fraction * 0.56, Math.sin(angle) * 0.18));
    }
    const coil = mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points), 144, 0.026, 6, false), 'steel', coilGroup);
    coil.receiveShadow = false;
    const cap = pivot(body, [0, 0.74, 0]);
    cylinder(0.235, 0.235, 0.075, 'red', cap, [0, 0, 0]);
    cylinder(0.20, 0.20, 0.06, 'cream', cap, [0, -0.062, 0]);
    for (const side of [-1, 1]) {
      ball(0.055, 'cream', cap, [side * 0.085, 0.045, 0.163], [1, 1.18, 0.74]);
      ball(0.023, 'ink', cap, [side * 0.085, 0.046, 0.201], [1, 1.16, 0.60]);
    }
    // An off-centre little antenna makes the spring readable from overhead.
    cylinder(0.011, 0.016, 0.13, 'steel', cap, [-0.075, 0.105, -0.03], 6);
    ball(0.032, 'red', cap, [-0.075, 0.186, -0.03]);
    pose = (t, stride) => {
      const cycle = t * 12.5;
      const compression = 1 + Math.sin(cycle) * 0.23 * stride + Math.sin(t * 2.3) * 0.026 * (1 - stride);
      coilGroup.scale.y = compression;
      coilGroup.rotation.x = Math.sin(cycle - 0.3) * 0.10 * stride;
      cap.position.y = 0.18 + 0.56 * compression;
      cap.position.z = Math.sin(cycle - 0.3) * 0.055 * stride;
      cap.rotation.x = Math.sin(cycle - 0.5) * 0.14 * stride;
      cap.rotation.z = Math.sin(t * 1.9) * 0.025;
      body.position.y = Math.max(0, Math.sin(cycle - 0.6)) * 0.105 * stride;
      base.rotation.x = Math.sin(cycle) * 0.08 * stride;
    };
  } else {
    const torso = pivot(body, [0, 0.39, -0.02]);
    ball(0.265, 'red', torso, [0, 0.015, -0.01], [0.79, 0.87, 1.3]);
    ball(0.17, 'cream', torso, [0, 0.035, 0.215], [0.82, 1.08, 0.45]);
    const head = pivot(torso, [0, 0.27, 0.22]);
    ball(0.215, 'red', head, [0, 0.015, 0], [1, 0.86, 0.94]);
    // Angular cream cheeks and an elongated muzzle distinguish the fox silhouette.
    for (const side of [-1, 1]) {
      const cheek = ball(0.135, 'cream', head, [side * 0.107, -0.047, 0.092], [0.85, 0.65, 1.2]);
      cheek.rotation.z = side * 0.27;
      const ear = mesh(new THREE.ConeGeometry(0.108, 0.26, 4), 'red', head, [side * 0.132, 0.20, -0.027]);
      ear.rotation.z = -side * 0.17;
      ear.rotation.y = Math.PI / 4;
      const insideEar = mesh(new THREE.ConeGeometry(0.062, 0.17, 3), 'ink', head, [side * 0.134, 0.207, 0.027]);
      insideEar.rotation.z = -side * 0.17;
      insideEar.scale.z = 0.23;
      ball(0.023, 'ink', head, [side * 0.113, 0.045, 0.161], [0.94, 1.13, 0.65]);
    }
    const snout = mesh(new THREE.ConeGeometry(0.098, 0.21, 5), 'cream', head, [0, -0.038, 0.208]);
    snout.rotation.x = Math.PI / 2;
    ball(0.037, 'ink', head, [0, -0.033, 0.312], [1, 0.8, 0.78]);
    const tail = pivot(torso, [0, 0.025, -0.26]);
    const brush = cylinder(0.15, 0.074, 0.42, 'red', tail, [0, 0.045, -0.195], 7);
    brush.rotation.x = -1.26;
    const tip = mesh(new THREE.ConeGeometry(0.145, 0.21, 7), 'cream', tail, [0, 0.14, -0.472]);
    tip.rotation.x = -1.26;
    const legs = [];
    for (const side of [-1, 1]) {
      for (const end of [-1, 1]) {
        const leg = pivot(body, [side * 0.143, 0.31, end * 0.185]);
        cylinder(0.052, 0.043, 0.19, 'red', leg, [0, -0.075, 0], 6);
        cylinder(0.044, 0.038, 0.14, 'ink', leg, [0, -0.215, 0], 6);
        ball(0.057, 'ink', leg, [0, -0.267, 0.027], [0.83, 0.68, 1.25]);
        legs.push({ object: leg, phase: side * end > 0 ? 0 : Math.PI });
      }
    }
    pose = (t, stride) => {
      const cycle = t * 13.5;
      torso.position.y = 0.39 + Math.abs(Math.sin(cycle)) * 0.035 * stride;
      torso.rotation.z = Math.sin(cycle) * 0.035 * stride;
      head.rotation.y = Math.sin(t * 1.45) * 0.09 * (1 - stride * 0.6);
      head.rotation.x = Math.sin(cycle - 0.35) * 0.05 * stride;
      tail.rotation.y = Math.sin(t * 3.5) * 0.19 + Math.sin(cycle * 0.5) * 0.18 * stride;
      tail.rotation.x = Math.sin(t * 2.8) * 0.035;
      legs.forEach(({ object, phase }) => { object.rotation.x = Math.sin(cycle + phase) * stride * 0.58; });
    };
  }

  let stride = 0;
  let disposed = false;
  pose(0, 0);

  return {
    group,
    update({ time = 0, delta = 1 / 60, moving = false, speed = 1 } = {}) {
      if (disposed) return;
      const target = moving ? Math.min(1, Math.max(0.45, Number(speed) || 1)) : 0;
      stride = THREE.MathUtils.damp(stride, target, 12, Math.min(0.1, Math.max(0, delta)));
      pose(time, stride);
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      const geometries = new Set();
      group.traverse(object => {
        if (object.geometry) geometries.add(object.geometry);
      });
      geometries.forEach(geometry => geometry.dispose());
      Object.values(materials).forEach(material => material.dispose());
      group.removeFromParent();
      group.clear();
    },
  };
}
