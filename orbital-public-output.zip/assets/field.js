import * as THREE from './vendor/three.module.min.js';
import { createAvatarRig } from './avatar-rigs.js';
import { PALETTE, FIELD_THEME, createFieldMaterials, addFieldLighting } from './field-theme.js';
import { buildLandmark, MODEL_KEYS } from './landmark-models.js';
import { DEFAULT_ISLAND, MAP_LIMITS, resolveIslandLayout } from './map-layout.js';

let catalogPromise;
async function loadModelCatalog() {
  catalogPromise ||= fetch(new URL('./model-catalog.json', import.meta.url)).then(response => {
    if (!response.ok) throw new Error('The landmark model catalog could not be loaded.');
    return response.json();
  }).catch(error => { catalogPromise = null; throw error; });
  return catalogPromise;
}

const clamp = THREE.MathUtils.clamp;
const ease = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;

export async function createField({
  mount,
  island: islandDefinition = DEFAULT_ISLAND,
  onSelect = () => {},
  onHover = () => {},
  onTravel = () => {},
  onReady = () => {},
  onError = () => {},
  onProject = () => {},
  avatarKind = 'fox',
  reducedMotion = false,
  paused = false,
} = {}) {
  if (!mount) throw new Error('The field needs a mount element.');
  const layout = resolveIslandLayout(islandDefinition, await loadModelCatalog());
  for (const landmark of layout.landmarks) {
    if (!MODEL_KEYS.includes(landmark.model)) throw new Error(`Model ${landmark.model} has no registered builder.`);
  }

  let renderer;
  try {
    renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' });
  } catch (error) {
    onError(error);
    throw error;
  }

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, FIELD_THEME.maxPixelRatio));
  renderer.setClearColor(0x000000, 0);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = FIELD_THEME.exposure;
  renderer.domElement.setAttribute('aria-hidden', 'true');
  renderer.domElement.style.display = 'block';
  renderer.domElement.style.width = '100%';
  renderer.domElement.style.height = '100%';
  renderer.domElement.style.touchAction = 'pan-y';
  mount.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.OrthographicCamera(-12, 12, 10, -10, 0.1, 120);
  const cameraTarget = new THREE.Vector3(0, 0.7, 0);
  const cameraBase = new THREE.Vector3(11, 22, 30);
  camera.position.copy(cameraBase);
  camera.lookAt(cameraTarget);
  addFieldLighting(scene);
  const materials = createFieldMaterials();
  const geometries = new Set();
  const ownGeometry = geometry => { geometries.add(geometry); return geometry; };
  const boxGeometry = ownGeometry(new THREE.BoxGeometry(1, 1, 1));
  const cylinderGeometry = ownGeometry(new THREE.CylinderGeometry(1, 1, 1, 16));

  function mesh(geometry, material, parent, x = 0, y = 0, z = 0) {
    const result = new THREE.Mesh(geometry, materials[material] || material);
    result.position.set(x, y, z);
    result.castShadow = true;
    result.receiveShadow = true;
    parent.add(result);
    return result;
  }

  function box(parent, material, x, y, z, width, height, depth) {
    const result = mesh(boxGeometry, material, parent, x, y, z);
    result.scale.set(width, height, depth);
    return result;
  }

  function cylinder(parent, material, x, y, z, radius, height) {
    const result = mesh(cylinderGeometry, material, parent, x, y, z);
    result.scale.set(radius, height, radius);
    return result;
  }

  function rod(parent, start, end, radius = 0.035, material = 'ink') {
    const a = new THREE.Vector3(...start);
    const b = new THREE.Vector3(...end);
    const midpoint = a.clone().add(b).multiplyScalar(0.5);
    const result = cylinder(parent, material, midpoint.x, midpoint.y, midpoint.z, radius, a.distanceTo(b));
    result.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.sub(a).normalize());
    return result;
  }

  const islandBase = new THREE.Group();
  scene.add(islandBase);
  box(islandBase, 'ink', 0, -0.84, 0, 19.1, 0.25, 14.9);
  box(islandBase, 'slab', 0, -0.4, 0, 19.6, 0.65, 15.4);
  box(islandBase, 'paper', 0, -0.06, 0, 19.4, 0.06, 15.2);
  // Front stair and recessed section marks give the world a physical, cut-out edge.
  box(islandBase, 'stone', 0, -0.53, 7.95, 5.2, 0.3, 0.65);
  box(islandBase, 'edge', 0, -0.72, 8.25, 5.6, 0.24, 0.6);
  for (let i = 0; i < 11; i++) box(islandBase, 'edge', -8.5 + i * 1.7, -0.36, 7.72, 0.018, 0.36, 0.025);
  for (const x of [-8.7, 8.7]) {
    for (const z of [-6.7, 6.7]) {
      box(islandBase, 'ink', x, 0.002, z, 0.5, 0.022, 0.045);
      box(islandBase, 'ink', x, 0.004, z, 0.045, 0.022, 0.5);
    }
  }
  // Quiet crossing paths, a material change rather than a network of decorative lines.
  box(islandBase, 'slab', 0, 0.005, 0, 1.25, 0.012, 13.8);
  box(islandBase, 'slab', 0, 0.006, 1.05, 17.8, 0.014, 1.25);
  box(islandBase, 'slab', 0, 0.006, -4.0, 15.5, 0.014, 0.6);

  const monuments = new Map();
  const pickables = [];

  function base(location) {
    const { width, depth, scale } = location;
    const group = new THREE.Group();
    group.position.set(location.x, 0, location.z);
    const sculpture = new THREE.Group();
    group.add(sculpture);
    sculpture.scale.setScalar(scale);
    box(group, 'stone', 0, 0.12 * scale, 0, width, 0.24 * scale, depth);
    box(group, 'ink', -width / 2 + 0.12 * scale, 0.254 * scale, depth / 2 - 0.18 * scale, 0.38 * scale, 0.016 * scale, 0.085 * scale);
    const marker = box(group, 'red', width / 2 - 0.14 * scale, 0.255 * scale, depth / 2 - 0.18 * scale, 0.15 * scale, 0.02 * scale, 0.15 * scale);
    marker.visible = false;
    scene.add(group);
    const entry = { ...location, group, sculpture, marker, width, depth, hover: 0, selected: false, landing: new THREE.Vector3(location.x, 0.03, location.z + depth / 2 + MAP_LIMITS.landingOffset) };
    monuments.set(location.id, entry);
    return { group, sculpture, entry };
  }

  // Model identity is independent of content identity and island order.
  const orderedMonuments = layout.landmarks.map(location => {
    const { sculpture, entry } = base(location);
    entry.animate = buildLandmark(location.model, { sculpture, box, cylinder, rod, mesh, ownGeometry, materials }).animate;
    entry.group.traverse(object => {
      if (object.isMesh) {
        object.userData.collectionId = entry.id;
        pickables.push(object);
      }
    });
    return entry;
  });

  function spawnPoint(isNarrow = false) {
    const bounds = MAP_LIMITS[isNarrow ? 'mobile' : 'desktop'];
    const candidates = [new THREE.Vector3(isNarrow ? 0 : 1.75, 0.03, isNarrow ? 0.4 : 3.4)];
    for (let z = bounds.halfDepth - 0.8; z > -bounds.halfDepth + 0.8; z -= 1.2) {
      for (let x = -bounds.halfWidth + 0.8; x < bounds.halfWidth - 0.8; x += 1.2) candidates.push(new THREE.Vector3(x, 0.03, z));
    }
    return candidates.find(point => !orderedMonuments.some(entry =>
      Math.abs(point.x - entry.x) < entry.width / 2 + MAP_LIMITS.pathMargin
      && Math.abs(point.z - entry.z) < entry.depth / 2 + MAP_LIMITS.pathMargin)) || candidates[0];
  }

  const destination = new THREE.Group();
  destination.position.y = 0.04;
  scene.add(destination);
  const targetRing = mesh(ownGeometry(new THREE.RingGeometry(0.43, 0.48, 32)), new THREE.MeshBasicMaterial({ color: PALETTE.red, side: THREE.DoubleSide }), destination);
  targetRing.rotation.x = -Math.PI / 2;
  targetRing.castShadow = false;
  const travelDots = new THREE.Group();
  scene.add(travelDots);
  for (let i = 0; i < 16; i++) {
    const dot = cylinder(travelDots, 'red', 0, 0.035, 0, 0.047, 0.025);
    dot.visible = false;
  }
  const avatarShadow = mesh(ownGeometry(new THREE.CircleGeometry(0.44, 24)), new THREE.MeshBasicMaterial({ color: 0x343b32, transparent: true, opacity: 0.16, depthWrite: false }), scene);
  avatarShadow.rotation.x = -Math.PI / 2;
  avatarShadow.castShadow = false;
  let avatar = createAvatarRig(avatarKind);
  avatar.group.scale.setScalar(FIELD_THEME.avatarScale.desktop);
  avatar.group.position.copy(spawnPoint());
  avatar.group.rotation.y = -0.5;
  scene.add(avatar.group);
  avatarShadow.position.copy(avatar.group.position);
  avatarShadow.position.y = 0.025;
  destination.visible = false;

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const cursor = new THREE.Vector2();
  const projected = new THREE.Vector3();
  let hoverId = null;
  let selectionId = null;
  let travel = null;
  let frame = 0;
  let lastTime = 0;
  let sceneTime = 0;
  let width = 1;
  let height = 1;
  let destroyed = false;
  let visible = !document.hidden;
  let inViewport = true;
  let firstFrame = true;
  let pointerDown = null;
  let lastTravelReport = 0;
  let narrow = false;
  let contextAvailable = true;
  let renderedFrames = 0;

  // A tiny visibility graph keeps the companion out of the architectural plinths.
  // It is solved on a click, never in the render loop. The margin includes its feet.
  function routeBetween(start, end) {
    const obstacles = orderedMonuments.map(entry => ({
      left: entry.x - entry.width / 2 - MAP_LIMITS.pathMargin,
      right: entry.x + entry.width / 2 + MAP_LIMITS.pathMargin,
      back: entry.z - entry.depth / 2 - MAP_LIMITS.pathMargin,
      front: entry.z + entry.depth / 2 + MAP_LIMITS.pathMargin,
    }));
    const inside = (point, rect) => point.x > rect.left && point.x < rect.right && point.z > rect.back && point.z < rect.front;
    const crosses = (a, b, rect) => {
      let lower = 0;
      let upper = 1;
      for (const [origin, direction, minimum, maximum] of [
        [a.x, b.x - a.x, rect.left, rect.right],
        [a.z, b.z - a.z, rect.back, rect.front],
      ]) {
        if (Math.abs(direction) < 0.00001) {
          if (origin <= minimum || origin >= maximum) return false;
        } else {
          const from = (minimum - origin) / direction;
          const to = (maximum - origin) / direction;
          lower = Math.max(lower, Math.min(from, to));
          upper = Math.min(upper, Math.max(from, to));
          if (lower >= upper) return false;
        }
      }
      return upper > 0.0001 && lower < 0.9999;
    };
    const nodes = [start.clone(), end.clone()];
    obstacles.forEach(rect => {
      for (const x of [rect.left - 0.035, rect.right + 0.035]) {
        for (const z of [rect.back - 0.035, rect.front + 0.035]) {
          const point = new THREE.Vector3(x, 0.03, z);
          if (Math.abs(x) < MAP_LIMITS[narrow ? 'mobile' : 'desktop'].halfWidth && Math.abs(z) < MAP_LIMITS[narrow ? 'mobile' : 'desktop'].halfDepth
            && !obstacles.some(other => inside(point, other))) nodes.push(point);
        }
      }
    });
    const distances = nodes.map(() => Infinity);
    const previous = nodes.map(() => -1);
    const visited = new Set();
    distances[0] = 0;
    while (visited.size < nodes.length) {
      let index = -1;
      nodes.forEach((node, i) => {
        if (!visited.has(i) && (index === -1 || distances[i] < distances[index])) index = i;
      });
      if (index === -1 || !Number.isFinite(distances[index]) || index === 1) break;
      visited.add(index);
      nodes.forEach((node, i) => {
        if (i === index || visited.has(i)) return;
        if (obstacles.some(rect => crosses(nodes[index], node, rect))) return;
        const distance = distances[index] + nodes[index].distanceTo(node);
        if (distance < distances[i]) { distances[i] = distance; previous[i] = index; }
      });
    }
    const path = [end.clone()];
    let index = 1;
    while (previous[index] !== -1) {
      index = previous[index];
      path.unshift(nodes[index]);
    }
    if (index !== 0) path.unshift(start.clone());
    const curve = new THREE.CurvePath();
    for (let i = 1; i < path.length; i++) curve.add(new THREE.LineCurve3(path[i - 1], path[i]));
    return curve;
  }

  function notifyTravel(progress, arrived) {
    if (!travel) return;
    onTravel({ id: travel.id, progress, arrived });
  }

  function updateTravel(delta) {
    if (!travel) return;
    travel.elapsed += delta;
    const progress = reducedMotion || paused ? 1 : clamp(travel.elapsed / travel.duration, 0, 1);
    const eased = ease(progress);
    const current = travel.curve.getPoint(eased);
    const ahead = travel.curve.getPoint(Math.min(eased + 0.015, 1));
    const direction = ahead.sub(current);
    avatar.group.position.copy(current);
    if (direction.lengthSq() > 0.000001) {
      const desired = Math.atan2(direction.x, direction.z);
      const difference = Math.atan2(Math.sin(desired - avatar.group.rotation.y), Math.cos(desired - avatar.group.rotation.y));
      avatar.group.rotation.y += difference * (1 - Math.exp(-delta * 18));
    }
    avatarShadow.position.set(current.x, 0.025, current.z);
    if (sceneTime - lastTravelReport > 0.075 || progress === 1) {
      notifyTravel(progress, progress === 1);
      lastTravelReport = sceneTime;
    }
    travelDots.children.forEach((dot, i) => { dot.visible = progress < 1 && i / 16 > eased; });
    if (progress === 1) {
      travel = null;
      destination.scale.setScalar(1);
    }
  }

  function moveTo(point, id = null) {
    const start = avatar.group.position.clone();
    const end = point.clone();
    destination.position.set(end.x, 0.04, end.z);
    destination.visible = true;
    if (start.distanceToSquared(end) < 0.0001) {
      travel = null;
      travelDots.children.forEach(dot => { dot.visible = false; });
      onTravel({ id, progress: 1, arrived: true });
      invalidate();
      return;
    }
    const curve = routeBetween(start, end);
    travel = { id, elapsed: 0, duration: clamp(curve.getLength() / FIELD_THEME.travel.speed, FIELD_THEME.travel.minimumSeconds, FIELD_THEME.travel.maximumSeconds), curve };
    travelDots.children.forEach((dot, i) => {
      const position = curve.getPoint((i + 1) / 17);
      dot.position.set(position.x, 0.035, position.z);
      dot.visible = !paused && !reducedMotion;
    });
    notifyTravel(0, false);
    if (reducedMotion || paused) updateTravel(0);
    invalidate();
  }

  function travelTo(id) {
    const entry = monuments.get(id);
    if (!entry) return;
    selectionId = id;
    orderedMonuments.forEach(item => { item.selected = item.id === id; item.marker.visible = item.selected; });
    moveTo(entry.landing, id);
  }

  function projectLabels() {
    camera.updateMatrixWorld();
    onProject(orderedMonuments.map(entry => {
      projected.set(entry.x, 0.14, entry.z + entry.depth / 2 + 0.4).project(camera);
      return { id: entry.id, x: (projected.x + 1) * width / 2, y: (1 - projected.y) * height / 2 };
    }));
  }

  function render(now = performance.now()) {
    frame = 0;
    if (destroyed || !visible || !inViewport || !contextAvailable) return;
    const delta = Math.min((now - (lastTime || now)) / 1000, 0.05);
    lastTime = now;
    const motion = !paused && !reducedMotion;
    if (motion) sceneTime += delta;
    const cameraBlend = motion ? 1 - Math.exp(-delta * 4.5) : 1;
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, cameraBase.x + (motion ? cursor.x * 1.4 : 0), cameraBlend);
    camera.position.z = THREE.MathUtils.lerp(camera.position.z, cameraBase.z + (motion ? cursor.y * 0.8 : 0), cameraBlend);
    camera.lookAt(cameraTarget);
    orderedMonuments.forEach(entry => {
      const target = entry.id === hoverId ? 1 : entry.selected ? 0.28 : 0;
      entry.hover = motion ? THREE.MathUtils.lerp(entry.hover, target, 1 - Math.exp(-delta * 8)) : target;
      entry.sculpture.position.y = motion ? entry.hover * 0.16 : 0;
      entry.sculpture.rotation.y = motion ? entry.hover * 0.055 : 0;
      entry.animate(sceneTime, entry.hover, motion);
    });
    updateTravel(delta);
    avatar.update({ time: sceneTime, delta: motion ? delta : 0, moving: !!travel && motion, speed: travel ? 1 : 0, reducedMotion: !motion });
    if (travel && motion) destination.scale.setScalar(1 + Math.sin(sceneTime * 6) * 0.08);
    renderer.render(scene, camera);
    renderedFrames++;
    projectLabels();
    if (firstFrame) {
      firstFrame = false;
      onReady();
    }
    if (motion || travel) frame = requestAnimationFrame(render);
  }

  function invalidate() {
    if (!frame && !destroyed && visible && inViewport && contextAvailable) frame = requestAnimationFrame(render);
  }

  function fitCamera() {
    camera.position.copy(cameraBase);
    camera.lookAt(cameraTarget);
    camera.updateMatrixWorld();
    const cameraSpace = new THREE.Vector3();
    let halfWidth = 0;
    let halfHeight = 0;
    const xRange = narrow ? [-7.6, 7.6] : [-10.0, 10.0];
    const zRange = narrow ? [-12.8, 13.1] : [-8.0, 8.6];
    for (const x of xRange) for (const y of [-1.0, Math.max(5.25, ...layout.landmarks.map(landmark => landmark.height + 0.7))]) for (const z of zRange) {
      cameraSpace.set(x, y, z).applyMatrix4(camera.matrixWorldInverse);
      halfWidth = Math.max(halfWidth, Math.abs(cameraSpace.x));
      halfHeight = Math.max(halfHeight, Math.abs(cameraSpace.y));
    }
    const aspect = width / height;
    const span = Math.max(halfHeight, halfWidth / aspect) * 1.055;
    camera.left = -span * aspect;
    camera.right = span * aspect;
    camera.top = span;
    camera.bottom = -span;
    camera.updateProjectionMatrix();
  }

  function resize() {
    if (destroyed) return;
    const bounds = mount.getBoundingClientRect();
    width = Math.max(1, bounds.width);
    height = Math.max(1, bounds.height);
    const nextNarrow = width / height < 0.94;
    if (nextNarrow !== narrow) {
      const reflowedTravel = travel;
      narrow = nextNarrow;
      islandBase.scale.set(narrow ? 0.75 : 1, 1, narrow ? 1.55 : 1);
      cameraBase.set(narrow ? 2 : 11, narrow ? 35 : 22, narrow ? 22 : 30);
      avatar.group.scale.setScalar(FIELD_THEME.avatarScale[narrow ? 'mobile' : 'desktop']);
      orderedMonuments.forEach((entry, index) => {
        const [x, z] = narrow ? [layout.landmarks[index].mobileX, layout.landmarks[index].mobileZ] : [layout.landmarks[index].x, layout.landmarks[index].z];
        entry.x = x;
        entry.z = z;
        entry.group.position.set(x, 0, z);
        entry.landing.set(x, 0.03, z + entry.depth / 2 + MAP_LIMITS.landingOffset);
      });
      travel = null;
      travelDots.children.forEach(dot => { dot.visible = false; });
      const spot = selectionId ? monuments.get(selectionId).landing : spawnPoint(narrow);
      avatar.group.position.copy(spot);
      avatarShadow.position.set(spot.x, 0.025, spot.z);
      destination.position.set(spot.x, 0.04, spot.z);
      destination.scale.setScalar(1);
      if (reflowedTravel) onTravel({ id: reflowedTravel.id, progress: 1, arrived: true });
    }
    renderer.setSize(width, height, false);
    fitCamera();
    invalidate();
  }

  function raycast(event) {
    const bounds = renderer.domElement.getBoundingClientRect();
    pointer.set((event.clientX - bounds.left) / bounds.width * 2 - 1, -(event.clientY - bounds.top) / bounds.height * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    return raycaster.intersectObjects(pickables, false)[0];
  }

  function setHover(id) {
    if (hoverId === id) return;
    hoverId = id;
    renderer.domElement.style.cursor = id ? 'pointer' : 'crosshair';
    onHover(id);
    invalidate();
  }

  function handleMove(event) {
    const hit = raycast(event);
    cursor.set(pointer.x, pointer.y);
    setHover(hit ? hit.object.userData.collectionId : null);
    invalidate();
  }

  function handleLeave() {
    cursor.set(0, 0);
    setHover(null);
    invalidate();
  }

  function handleDown(event) { pointerDown = { x: event.clientX, y: event.clientY }; }

  function handleUp(event) {
    if (!pointerDown || Math.hypot(event.clientX - pointerDown.x, event.clientY - pointerDown.y) > 9) {
      pointerDown = null;
      return;
    }
    pointerDown = null;
    const hit = raycast(event);
    if (hit) {
      const id = hit.object.userData.collectionId;
      onSelect(id);
      return;
    }
    const point = new THREE.Vector3();
    if (raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), -0.03), point)
      && Math.abs(point.x) < MAP_LIMITS[narrow ? 'mobile' : 'desktop'].halfWidth - 0.15 && Math.abs(point.z) < MAP_LIMITS[narrow ? 'mobile' : 'desktop'].halfDepth - 0.1) moveTo(point);
  }

  function updateVisibility() {
    visible = !document.hidden;
    lastTime = 0;
    if (!visible && frame) { cancelAnimationFrame(frame); frame = 0; }
    if (visible) invalidate();
  }

  function contextLost(event) {
    event.preventDefault();
    contextAvailable = false;
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    onError(new Error('The 3D field lost its graphics context. The collection index is still available.'));
  }

  function contextRestored() {
    contextAvailable = true;
    firstFrame = true;
    lastTime = 0;
    invalidate();
  }

  renderer.domElement.addEventListener('pointermove', handleMove);
  renderer.domElement.addEventListener('pointerleave', handleLeave);
  renderer.domElement.addEventListener('pointerdown', handleDown);
  renderer.domElement.addEventListener('pointerup', handleUp);
  renderer.domElement.addEventListener('pointercancel', handleLeave);
  renderer.domElement.addEventListener('webglcontextlost', contextLost);
  renderer.domElement.addEventListener('webglcontextrestored', contextRestored);
  document.addEventListener('visibilitychange', updateVisibility);
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(mount);
  const intersectionObserver = new IntersectionObserver(entries => {
    inViewport = entries[0].isIntersecting;
    lastTime = 0;
    if (!inViewport && frame) { cancelAnimationFrame(frame); frame = 0; }
    if (inViewport) invalidate();
  }, { rootMargin: '100px' });
  intersectionObserver.observe(mount);
  resize();

  return {
    travelTo,
    resize,
    resetCamera() { cursor.set(0, 0); fitCamera(); invalidate(); },
    setHover,
    highlight: setHover,
    getState() {
      return {
        islandId: layout.id, landmarkIds: orderedMonuments.map(entry => entry.id),
        avatarKind, position: avatar.group.position.toArray(), selectedId: selectionId,
        hoverId, traveling: Boolean(travel), destinationId: travel?.id || null,
        progress: travel ? clamp(travel.elapsed / travel.duration, 0, 1) : 1,
        paused, reducedMotion, visible: visible && inViewport, narrow, renderedFrames,
      };
    },
    setAvatar(kind) {
      const position = avatar.group.position.clone();
      const rotation = avatar.group.rotation.clone();
      scene.remove(avatar.group);
      avatar.dispose();
      avatar = createAvatarRig(kind);
      avatarKind = kind;
      avatar.group.scale.setScalar(FIELD_THEME.avatarScale[narrow ? 'mobile' : 'desktop']);
      avatar.group.position.copy(position);
      avatar.group.rotation.copy(rotation);
      scene.add(avatar.group);
      invalidate();
    },
    setPaused(value) {
      paused = Boolean(value);
      lastTime = 0;
      if (paused && travel) updateTravel(0);
      invalidate();
    },
    setReducedMotion(value) {
      reducedMotion = Boolean(value);
      lastTime = 0;
      if (reducedMotion && travel) updateTravel(0);
      invalidate();
    },
    destroy() {
      destroyed = true;
      cancelAnimationFrame(frame);
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
      document.removeEventListener('visibilitychange', updateVisibility);
      renderer.domElement.removeEventListener('pointermove', handleMove);
      renderer.domElement.removeEventListener('pointerleave', handleLeave);
      renderer.domElement.removeEventListener('pointerdown', handleDown);
      renderer.domElement.removeEventListener('pointerup', handleUp);
      renderer.domElement.removeEventListener('pointercancel', handleLeave);
      renderer.domElement.removeEventListener('webglcontextlost', contextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', contextRestored);
      avatar.dispose();
      const allMaterials = new Set(Object.values(materials));
      scene.traverse(object => {
        if (object.geometry) geometries.add(object.geometry);
        if (object.material) (Array.isArray(object.material) ? object.material : [object.material]).forEach(material => allMaterials.add(material));
      });
      geometries.forEach(geometry => geometry.dispose());
      allMaterials.forEach(material => material.dispose());
      renderer.dispose();
      renderer.domElement.remove();
    },
  };
}
