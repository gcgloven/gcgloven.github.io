/* Read-only database views enhance the complete static table, never its content. */
(() => {
  const workspace = document.querySelector('[data-workspace]');
  if (!workspace) return;
  const table = document.getElementById('workspace-table');
  const list = document.getElementById('workspace-list');
  if (!table || !list) return;
  const search = document.getElementById('workspace-search');
  const sort = document.getElementById('workspace-sort');
  const filters = Object.fromEntries(['category','topic','type','tag'].map(name => [name, document.getElementById(`workspace-${name}`)]));
  const from = document.getElementById('workspace-from');
  const to = document.getElementById('workspace-to');
  const validDate = value => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0,10) === value;
  const featured = document.getElementById('workspace-featured');
  const reset = document.getElementById('workspace-reset');
  const views = [...workspace.querySelectorAll('[data-workspace-view]')];
  const containers = [table.querySelector('tbody'),list];
  const groups = containers.map(container => [...container.querySelectorAll('[data-entry]')]);
  const tags = new WeakMap(groups.flat().map(entry => [entry,JSON.parse(entry.dataset.tags || '[]')]));
  const total = groups[0].length;
  let view = 'table';
  for (const control of workspace.querySelectorAll('[data-workspace-control]')) control.disabled = false;

  function apply(writeUrl = true) {
    const terms = search.value.trim().toLocaleLowerCase().split(/\s+/).filter(Boolean);
    let count = 0;
    groups.forEach((entries,index) => {
      entries.sort((a,b) => {
        if (sort.value === 'title') return a.dataset.title.localeCompare(b.dataset.title);
        const aDate = a.dataset.date, bDate = b.dataset.date;
        if (!aDate && bDate) return 1;
        if (aDate && !bDate) return -1;
        return bDate.localeCompare(aDate) || a.dataset.title.localeCompare(b.dataset.title);
      });
      for (const entry of entries) {
        const visible = terms.every(term => entry.dataset.search.includes(term))
          && Object.entries(filters).every(([name,control]) => !control?.value || (name === 'tag' ? tags.get(entry).includes(control.value) : entry.dataset[name] === control.value))
          && (!from.value || (entry.dataset.date && entry.dataset.date >= from.value))
          && (!to.value || (entry.dataset.date && entry.dataset.date <= to.value))
          && (!featured?.checked || entry.dataset.featured === 'true');
        entry.hidden = !visible;
        const childContext = entry.querySelector('[data-child-matches]');
        if (childContext) {
          let childCount = 0;
          for (const child of childContext.querySelectorAll('[data-child]')) {
            const matches = Boolean(visible && terms.length && terms.every(term => child.dataset.childSearch.includes(term)));
            child.hidden = !matches;
            if (matches) childCount++;
          }
          childContext.hidden = childCount === 0;
        }
        if (visible && index === 0) count++;
        containers[index].append(entry);
      }
    });
    table.hidden = view !== 'table';
    list.hidden = view !== 'list';
    views.forEach(button => button.setAttribute('aria-pressed',String(button.dataset.workspaceView === view)));
    document.getElementById('workspace-count').textContent = `${count} of ${total} ${total === 1 ? 'entry' : 'entries'}`;
    document.getElementById('workspace-no-results').hidden = count !== 0;
    document.getElementById('workspace-filter-note').hidden = !(from.value && to.value && from.value > to.value);
    reset.disabled = !from.value && !to.value && !search.value.trim() && !Object.values(filters).some(control => control?.value) && !featured?.checked;
    if (writeUrl) {
      const url = new URL(location.href);
      const values = {q:search.value.trim(),from:from.value,to:to.value,...Object.fromEntries(Object.entries(filters).map(([name,control]) => [name,control?.value || ''])),featured:featured?.checked ? '1' : '',sort:sort.value === 'latest' ? '' : sort.value,view:view === 'table' ? '' : view};
      for (const [key,value] of Object.entries(values)) { if (value) url.searchParams.set(key,value); else url.searchParams.delete(key); }
      history.replaceState(null,'',url);
    }
  }
  function restore() {
    const params = new URLSearchParams(location.search);
    search.value = params.get('q') || '';
    for (const [name,control] of Object.entries(filters)) {
      if (!control) continue;
      const value = params.get(name) || '';
      control.value = [...control.options].some(option => option.value === value) ? value : '';
    }
    from.value = validDate(params.get('from') || '') ? params.get('from') : '';
    to.value = validDate(params.get('to') || '') ? params.get('to') : '';
    if (featured) featured.checked = params.get('featured') === '1';
    sort.value = params.get('sort') === 'title' ? 'title' : 'latest';
    view = params.get('view') === 'list' ? 'list' : 'table';
    apply(false);
  }
  function clearFilters() {
    search.value = '';
    from.value = ''; to.value = '';
    for (const control of Object.values(filters)) if (control) control.value = '';
    if (featured) featured.checked = false;
    apply();
    search.focus();
  }
  search.addEventListener('input',()=>apply());
  sort.addEventListener('change',()=>apply());
  from.addEventListener('change',()=>apply());
  to.addEventListener('change',()=>apply());
  for (const control of Object.values(filters)) control?.addEventListener('change',()=>apply());
  featured?.addEventListener('change',()=>apply());
  reset.addEventListener('click',clearFilters);
  document.getElementById('workspace-empty-reset').addEventListener('click',clearFilters);
  views.forEach(button => button.addEventListener('click',()=>{view=button.dataset.workspaceView;apply();}));
  document.addEventListener('keydown',event => {
    const active = document.activeElement;
    const typing = /INPUT|TEXTAREA|SELECT/.test(active?.tagName || '') || active?.isContentEditable;
    if (event.key === '/' && !typing && !event.ctrlKey && !event.metaKey && !event.altKey) { event.preventDefault(); search.focus(); }
    if (event.key === 'Escape' && active === search) { search.value=''; apply(); search.blur(); }
  });
  window.addEventListener('popstate',restore);
  restore();
})();
