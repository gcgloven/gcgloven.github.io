// Pure data helpers: used by the browser field and the publishing validator.
// Coordinates are ground-plane world units: x = left/right, z = back/front.
export const MAP_LIMITS = Object.freeze({
  minLandmarks: 1,
  maxLandmarks: 7,
  minScale: 0.6,
  maxScale: 1.3,
  clearance: 0.85,
  pathMargin: 0.4,
  landingOffset: 0.7,
  desktop: { halfWidth: 9.4, halfDepth: 7.1 },
  mobile: { halfWidth: 6.9, halfDepth: 11.6 },
});

export const DEFAULT_ISLAND = Object.freeze({
  id: 'observatory',
  title: 'Observatory',
  layout: 'manual',
  landmarks: [
    { collection: 'house', model: 'building', x: -5.2, z: -3.8, mobileX: -4, mobileZ: -7.4, scale: 1 },
    { collection: 'expeditions', model: 'dish', x: 0.6, z: -5, mobileX: 4, mobileZ: -7.4, scale: 1 },
    { collection: 'journal', model: 'portal', x: 6.1, z: -3.5, mobileX: 0, mobileZ: 8.2, scale: 1 },
    { collection: 'papers', model: 'book', x: -6.1, z: 2, mobileX: -4, mobileZ: -1.7, scale: 1 },
    { collection: 'projects', model: 'gyroscope', x: 0, z: 0, mobileX: 4, mobileZ: -1.7, scale: 1 },
    { collection: 'trajectory', model: 'stairs', x: 5.5, z: 2.9, mobileX: 4, mobileZ: 3.8, scale: 1 },
    { collection: 'fragments', model: 'fragments', x: -1.3, z: 5, mobileX: -4, mobileZ: 3.8, scale: 1 },
  ],
});

const DESKTOP_SLOTS = {
  1: [[0, 0]],
  2: [[-3.8, 0], [3.8, 0]],
  3: [[-5.9, 0], [0, 0], [5.9, 0]],
  4: [[-4, -3], [4, -3], [-4, 3], [4, 3]],
  5: [[-5.9, -3], [0, -3], [5.9, -3], [-3, 3], [3, 3]],
  6: [[-5.9, -3], [0, -3], [5.9, -3], [-5.9, 3], [0, 3], [5.9, 3]],
  7: [[-5.2, -3.8], [0.6, -4.8], [6.1, -3.5], [-6.1, 2], [0, 0], [5.5, 2.9], [-1.3, 4.6]],
};
const MOBILE_SLOTS = {
  1: [[0, 0]],
  2: [[-4, 0], [4, 0]],
  3: [[-4, -3], [4, -3], [0, 3]],
  4: [[-4, -3], [4, -3], [-4, 3], [4, 3]],
  5: [[-4, -5.5], [4, -5.5], [-4, 0], [4, 0], [0, 5.5]],
  6: [[-4, -5.5], [4, -5.5], [-4, 0], [4, 0], [-4, 5.5], [4, 5.5]],
  7: [[-4, -7.4], [4, -7.4], [-4, -1.7], [4, -1.7], [-4, 3.8], [4, 3.8], [0, 8.2]],
};

export function automaticPositions(count) {
  if (!Number.isInteger(count) || count < 1 || count > 7) {
    throw new Error('An island needs between 1 and 7 landmarks.');
  }
  return DESKTOP_SLOTS[count].map(([x, z], index) => ({
    x, z, mobileX: MOBILE_SLOTS[count][index][0], mobileZ: MOBILE_SLOTS[count][index][1],
  }));
}

function finite(value, name) {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(`${name} must be a finite number.`);
  return value;
}

function positive(value, name) {
  finite(value, name);
  if (value <= 0) throw new Error(`${name} must be greater than zero.`);
  return value;
}

function validatePositions(landmarks, mode) {
  const bounds = MAP_LIMITS[mode];
  const xKey = mode === 'mobile' ? 'mobileX' : 'x';
  const zKey = mode === 'mobile' ? 'mobileZ' : 'z';
  for (const landmark of landmarks) {
    const { id, width, depth } = landmark;
    const x = landmark[xKey];
    const z = landmark[zKey];
    if (Math.abs(x) + width / 2 + MAP_LIMITS.pathMargin > bounds.halfWidth
      || z - depth / 2 - MAP_LIMITS.pathMargin < -bounds.halfDepth
      || z + depth / 2 + MAP_LIMITS.landingOffset > bounds.halfDepth) {
      throw new Error(`${id}: ${mode} position is outside the island's usable area. Move it inward or reduce its scale.`);
    }
  }
  for (let a = 0; a < landmarks.length; a++) {
    for (let b = a + 1; b < landmarks.length; b++) {
      const first = landmarks[a];
      const second = landmarks[b];
      if (Math.abs(first[xKey] - second[xKey]) < (first.width + second.width) / 2 + MAP_LIMITS.clearance
        && Math.abs(first[zKey] - second[zKey]) < (first.depth + second.depth) / 2 + MAP_LIMITS.clearance) {
        throw new Error(`${first.id} and ${second.id}: ${mode} plinths are too close. Leave at least ${MAP_LIMITS.clearance} world units between them.`);
      }
    }
  }
  for (const landmark of landmarks) {
    const landingX = landmark[xKey];
    const landingZ = landmark[zKey] + landmark.depth / 2 + MAP_LIMITS.landingOffset;
    const blocker = landmarks.find(other => other !== landmark
      && Math.abs(landingX - other[xKey]) < other.width / 2 + MAP_LIMITS.pathMargin
      && Math.abs(landingZ - other[zKey]) < other.depth / 2 + MAP_LIMITS.pathMargin);
    if (blocker) throw new Error(`${landmark.id}: ${mode} arrival space is blocked by ${blocker.id}. Move these objects farther apart.`);
  }

}

/** Resolve CMS data, validate both responsive layouts, and return scaled dimensions. */
export function resolveIslandLayout(island = DEFAULT_ISLAND, modelCatalog) {
  if (!island || typeof island !== 'object') throw new Error('An island must be an object.');
  if (!Array.isArray(modelCatalog) || !modelCatalog.length) throw new Error('The landmark model catalog is missing.');
  if (island.layout !== 'auto' && island.layout !== 'manual') throw new Error('Island layout must be auto or manual.');
  if (!Array.isArray(island.landmarks)) throw new Error('An island needs a landmarks list.');
  const slots = automaticPositions(island.landmarks.length);
  const seen = new Set();
  const landmarks = island.landmarks.map((landmark, index) => {
    const id = landmark.collection;
    if (typeof id !== 'string' || !id.trim()) throw new Error(`Landmark ${index + 1} needs a collection ID.`);
    if (seen.has(id)) throw new Error(`Collection ${id} appears more than once on this island.`);
    seen.add(id);
    const definition = modelCatalog.find(model => model.value === landmark.model);
    if (!definition) throw new Error(`${id}: unknown landmark model ${landmark.model}.`);
    const scale = finite(landmark.scale ?? 1, `${id} scale`);
    if (scale < MAP_LIMITS.minScale || scale > MAP_LIMITS.maxScale) {
      throw new Error(`${id}: scale must be between ${MAP_LIMITS.minScale} and ${MAP_LIMITS.maxScale}.`);
    }
    const position = island.layout === 'auto' ? slots[index] : landmark;
    return {
      id, collection: id, model: landmark.model, scale,
      x: finite(position.x, `${id} x`), z: finite(position.z, `${id} z`),
      mobileX: finite(position.mobileX, `${id} mobileX`), mobileZ: finite(position.mobileZ, `${id} mobileZ`),
      width: positive(definition.width, `${landmark.model} width`) * scale,
      depth: positive(definition.depth, `${landmark.model} depth`) * scale,
      height: positive(definition.height, `${landmark.model} height`) * scale,
    };
  });
  validatePositions(landmarks, 'desktop');
  validatePositions(landmarks, 'mobile');
  return { id: island.id || 'island', title: island.title || 'Island', layout: island.layout, landmarks };
}
