/* Search enhances an otherwise completely navigable static wiki. */
(() => {
  const search = document.getElementById('wiki-search');
  if (!search) return;
  const results = document.getElementById('wiki-search-results');
  const status = document.getElementById('wiki-search-status');
  const clear = document.getElementById('wiki-search-clear');
  const entries = [...document.querySelectorAll('[data-wiki-search]')];
  search.disabled = false;
  function apply(writeUrl = true) {
    const query = search.value.trim();
    const terms = query.toLocaleLowerCase().split(/\s+/).filter(Boolean);
    let count = 0;
    for (const entry of entries) {
      const visible = terms.length > 0 && terms.every(term => entry.dataset.wikiSearch.includes(term));
      entry.hidden = !visible;
      if (visible) count++;
    }
    results.hidden = terms.length === 0;
    clear.hidden = terms.length === 0;
    status.textContent = count ? `${count} ${count===1?'result':'results'}` : 'No matching pages. Try a broader word, or explore the topic hubs below.';
    if (writeUrl) {
      const url = new URL(location.href);
      if (query) url.searchParams.set('q',query); else url.searchParams.delete('q');
      history.replaceState(null,'',url);
    }
  }
  function restore() { search.value = new URLSearchParams(location.search).get('q') || ''; apply(false); }
  search.addEventListener('input',()=>apply());
  clear.addEventListener('click',()=>{search.value='';apply();search.focus();});
  document.addEventListener('keydown',event=>{
    const active = document.activeElement;
    const typing = /INPUT|TEXTAREA|SELECT/.test(active?.tagName || '') || active?.isContentEditable;
    if (event.key==='/'&&!typing&&!event.ctrlKey&&!event.metaKey&&!event.altKey) {event.preventDefault();search.focus();}
    if (event.key==='Escape'&&active===search) {search.value='';apply();search.blur();}
  });
  window.addEventListener('popstate',restore);
  restore();
})();
