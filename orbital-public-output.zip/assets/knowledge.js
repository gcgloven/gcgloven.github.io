/* Progressive enhancement only: published notes and links work without JavaScript. */
(() => {
  const vault = document.querySelector('[data-vault]');
  if (!vault) return;
  const list = document.getElementById('vault-list');
  const table = document.getElementById('vault-table');
  if (!list || !table) return;
  const search = document.getElementById('vault-search');
  const sort = document.getElementById('vault-sort');
  const topics = [...vault.querySelectorAll('[data-topic]')];
  const views = [...vault.querySelectorAll('[data-vault-view]')];
  const lists = [list, table.querySelector('tbody')];
  const groups = lists.map(container => [...container.querySelectorAll('[data-reading]')]);
  const total = groups[0].length;
  let topic = '';
  let view = 'list';
  for (const control of vault.querySelectorAll('[data-vault-control]')) control.disabled = false;

  function apply(writeUrl = true) {
    const query = search.value.trim().toLocaleLowerCase();
    const terms = query.split(/\s+/).filter(Boolean);
    let count = 0;
    groups.forEach((entries, index) => {
      entries.sort((a,b) => {
        if (sort.value === 'title') return a.dataset.title.localeCompare(b.dataset.title);
        // Undated entries stay at the end in either date order.
        const aDate = a.dataset.date, bDate = b.dataset.date;
        if (!aDate && bDate) return 1;
        if (aDate && !bDate) return -1;
        return (sort.value === 'oldest' ? aDate.localeCompare(bDate) : bDate.localeCompare(aDate)) || a.dataset.title.localeCompare(b.dataset.title);
      });
      entries.forEach(entry => {
        const visible = (!topic || entry.dataset.topicId === topic) && terms.every(term => entry.dataset.search.includes(term));
        entry.hidden = !visible;
        if (visible && index === 0) count++;
        lists[index].append(entry);
      });
    });
    topics.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.topic === topic)));
    views.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.vaultView === view)));
    list.hidden = view !== 'list';
    table.hidden = view !== 'table';
    document.getElementById('vault-result-count').textContent = `${count} of ${total} ${total === 1 ? 'reading' : 'readings'}`;
    document.getElementById('vault-no-results').hidden = count !== 0;
    if (writeUrl) {
      const url = new URL(location.href);
      for (const [key,value] of Object.entries({q: search.value.trim(), topic, sort: sort.value === 'latest' ? '' : sort.value, view: view === 'list' ? '' : view})) {
        if (value) url.searchParams.set(key, value); else url.searchParams.delete(key);
      }
      history.replaceState(null, '', url);
    }
  }
  function restore() {
    const params = new URLSearchParams(location.search);
    search.value = params.get('q') || '';
    const selectedTopic = params.get('topic') || '';
    topic = topics.some(button => button.dataset.topic === selectedTopic) ? selectedTopic : '';
    sort.value = ['oldest','title'].includes(params.get('sort')) ? params.get('sort') : 'latest';
    view = params.get('view') === 'table' ? 'table' : 'list';
    apply(false);
  }
  search.addEventListener('input', () => apply());
  sort.addEventListener('change', () => apply());
  topics.forEach(button => button.addEventListener('click', () => { topic = button.dataset.topic; apply(); }));
  views.forEach(button => button.addEventListener('click', () => { view = button.dataset.vaultView; apply(); }));
  document.getElementById('vault-clear').addEventListener('click', () => { search.value = ''; topic = ''; apply(); search.focus(); });
  window.addEventListener('popstate', restore);
  restore();
})();
