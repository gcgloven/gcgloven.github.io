/* Public interaction only. Writing happens in the separate local editor. */
'use strict';
const { collection, projects, pages, islands, site } = window.OBSERVATORY_CONTENT;
const byId = new Map(collection.map(item => [item.id, item]));
const companions = { fox:'Fox', plant:'Plant', duck:'Duck', spring:'Spring' };
const avatarKeys = Object.keys(companions);
const query = new URLSearchParams(location.search);
let avatarKind = avatarKeys.includes(query.get('avatar')) ? query.get('avatar') : avatarKeys[Math.floor(Math.random()*avatarKeys.length)];
let activeIsland = islands.find(island=>island.id===query.get('island')) || islands[0];
let selectedId = null, pendingArrival = null, selectedView = 'field', field = null, fieldVersion = 0, fieldFailed = false, lastTrigger = null, paused = false;
const visited = new Set();
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const touchPointer = matchMedia('(pointer: coarse)');
const $ = selector => document.querySelector(selector);
const dialog = $('#reading-dialog'), dialogBody = $('#dialog-body'), announcer = $('#announcer');
const labels = $('#field-labels'), index = $('#archive-index'), viewport = $('#field-viewport');
let labelNodes = {};
try { paused = localStorage.getItem('observatory-field-paused') === 'true'; } catch {}
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const draftLabel = item => item.status==='draft'?'<small class="draft-badge">Local draft</small>':'';
function indexRow(item) {
  return `<button class="index-row" type="button" data-open="${item.id}"><span class="index-row-number" aria-hidden="true">${item.number}</span><span><span class="index-row-title">${escapeHTML(item.title)}</span><span class="index-row-description">${escapeHTML(item.description)}</span>${draftLabel(item)}</span><span class="index-row-arrow" aria-hidden="true">→</span></button>`;
}
function pageLink(page) { return `<a class="content-page-link" href="${escapeHTML(page.url)}" data-page="${page.id}"><strong>${escapeHTML(page.title)}</strong><span>${escapeHTML(page.description)}</span>${draftLabel(page)}</a>`; }
function projectLink(key) {
  const p=projects[key];
  return `<a class="project-link" href="${escapeHTML(p.url)}" target="_blank" rel="noopener noreferrer"><span><strong>${escapeHTML(p.name)}</strong><small>${escapeHTML(p.description)}</small><small>${escapeHTML(p.domain)} · opens in a new tab</small></span><span class="external-arrow" aria-hidden="true">↗</span></a>`;
}
function updateFieldHint() { $('#field-hint').textContent=touchPointer.matches?'Tap a landmark. Follow your curiosity.':'Move your cursor. Choose a landmark.'; }
updateFieldHint();touchPointer.addEventListener('change',updateFieldHint);
index.innerHTML=collection.map(indexRow).join('');
document.querySelectorAll('.site-header [data-open]').forEach(button=>{if(!byId.has(button.dataset.open)&&!['utility:archive','utility:search'].includes(button.dataset.open))button.remove();});
const islandSelect=$('#island-select');
islandSelect.innerHTML=islands.map(island=>`<option value="${island.id}">${escapeHTML(island.title)}${island.status==='draft'?' · local draft':''}</option>`).join('');
$('#island-navigation').hidden=islands.length<2;
function islandItems() { return activeIsland.landmarks.map(node=>byId.get(node.collection)).filter(Boolean); }
function updateVisited() {const items=islandItems();$('#visited-count').textContent=`${items.filter(item=>visited.has(item.id)).length} / ${items.length} explored`;}
function highlightCollection(id) {$('#hover-label').textContent=byId.get(id)?.title || `${islandItems().length} landmarks. No set route.`;}
function renderMapControls() {
  const items=islandItems();islandSelect.value=activeIsland.id;$('#island-description').textContent=activeIsland.description;
  labels.innerHTML=items.map(item=>`<button class="landmark-button" type="button" data-select="${item.id}" aria-pressed="${selectedId===item.id}"><span class="label-text"><span class="label-number">${item.number}</span> ${escapeHTML(item.label)}</span><span class="sr-only">: visit ${escapeHTML(item.title)}</span></button>`).join('');
  $('#collection-dock').innerHTML=items.map(item=>`<button type="button" class="dock-item" data-select="${item.id}" aria-pressed="${selectedId===item.id}"><span class="dock-number" aria-hidden="true">${item.number}</span><span>${escapeHTML(item.label)}</span></button>`).join('');
  $('#collection-dock').style.setProperty('--landmark-count',items.length);
  labelNodes=Object.fromEntries([...labels.children].map(node=>[node.dataset.select,node]));
  for(const node of labels.children) {
    for(const name of ['pointerenter','focus'])node.addEventListener(name,()=>{field?.highlight(node.dataset.select);highlightCollection(node.dataset.select);});
    for(const name of ['pointerleave','blur'])node.addEventListener(name,()=>{field?.highlight(null);highlightCollection(null);});
  }
  updateVisited();highlightCollection(null);
}
function setCompanion(kind,announce=false) {
  avatarKind=kind;$('#companion-name').textContent=companions[kind];document.documentElement.dataset.companion=kind;field?.setAvatar(kind);
  if(selectedId)$('#journey-state').textContent=pendingArrival?`${companions[kind]} is on the way. Opens on arrival.`:`${companions[kind]} is ready to explore.`;
  if(announce)announcer.textContent=`Your companion is now a ${kind}.`;
}
function syncFieldMotion() {
  const still=paused||reducedMotion.matches;document.documentElement.dataset.motion=still?'still':'moving';
  const button=$('#motion-control');button.textContent=reducedMotion.matches?'Motion off':paused?'Resume motion':'Pause motion';
  button.setAttribute('aria-pressed',String(still));button.disabled=reducedMotion.matches;button.title=reducedMotion.matches?'Follows your device reduced-motion preference.':'';
  field?.setReducedMotion(reducedMotion.matches);field?.setPaused(paused||dialog.open||selectedView!=='field');
}
function setView(view) {
  if(view==='field'&&fieldFailed)return;if(view!=='field')pendingArrival=null;
  selectedView=view;viewport.hidden=view!=='field';index.hidden=view!=='index';
  document.querySelectorAll('[data-view]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.view===view)));
  $('#reset-view').hidden=view!=='field';$('#motion-control').hidden=view!=='field';syncFieldMotion();if(view==='field')field?.resize();
  announcer.textContent=view==='field'?'Interactive field selected.':`All ${collection.length} collections are available in the index.`;
}
function selectCollection(id,{autoOpen=true,trigger=null}={}) {
  const item=byId.get(id);if(!item)return;selectedId=id;pendingArrival=autoOpen?{id,trigger:trigger||labelNodes[id]}:null;visited.add(id);
  document.body.classList.add('has-selection');$('#selection-category').textContent=item.status==='draft'?'Local draft':'Selected collection';
  $('#selection-number').textContent=item.number;$('#selection-title').textContent=item.title;$('#selection-description').textContent=item.description;
  const opener=$('#open-selection');opener.dataset.open=id;opener.innerHTML='Open collection <span aria-hidden="true">→</span>';
  const targetIsland=activeIsland.landmarks.some(node=>node.collection===id)?activeIsland:islands.find(island=>island.landmarks.some(node=>node.collection===id));
  if(targetIsland&&targetIsland.id!==activeIsland.id)changeIsland(targetIsland.id,true);
  document.querySelectorAll('[data-select]').forEach(button=>{button.setAttribute('aria-pressed',String(button.dataset.select===id));button.classList.toggle('is-visited',visited.has(button.dataset.select));});
  updateVisited();$('#journey-line').style.transform='scaleX(0)';$('#journey-state').textContent=targetIsland?`${companions[avatarKind]} is on the way. Opens on arrival.`:'Ready to read.';
  announcer.textContent=`${item.title} selected. The collection opens on arrival. Use Open collection to read now.`;
  if(targetIsland)field?.travelTo(id);
}
function changeIsland(id,preserveSelection=false) {
  const island=islands.find(entry=>entry.id===id);if(!island)return;activeIsland=island;
  if(!preserveSelection){
    pendingArrival=null;selectedId=null;document.body.classList.remove('has-selection');$('#selection-category').textContent='Start anywhere';$('#selection-number').textContent='↗';$('#selection-title').textContent='Follow a curiosity.';
    $('#selection-description').textContent='Choose a landmark. Its collection opens when your companion arrives, or use the button to read sooner.';
    $('#open-selection').dataset.open=islandItems()[0].id;$('#open-selection').innerHTML='Start exploring <span aria-hidden="true">→</span>';
    $('#journey-state').textContent='Or explore the field in any order.';$('#journey-line').style.transform='scaleX(0)';
  }
  const url=new URL(location.href);url.searchParams.set('island',id);history.replaceState(null,'',url);renderMapControls();startField();
}
function fieldUnavailable() {
  if(fieldFailed)return;fieldFailed=true;document.documentElement.dataset.field='fallback';$('#field-loading').hidden=true;labels.hidden=true;
  if(!$('.field-fallback-note'))index.insertAdjacentHTML('afterbegin','<p class="field-fallback-note">The 3D field is unavailable in this browser. You can explore every collection here.</p>');
  $('[data-view="field"]').disabled=true;setView('index');
}
async function startField() {
  const version=++fieldVersion;field?.destroy();field=null;$('#field-canvas-container').replaceChildren();labels.hidden=true;$('#field-loading').hidden=false;
  fieldFailed=false;$('[data-view="field"]').disabled=false;$('.field-fallback-note')?.remove();document.documentElement.dataset.field='loading';
  try {
    const {createField}=await import('./field.js');if(version!==fieldVersion)return;
    const created=await createField({mount:$('#field-canvas-container'),island:activeIsland,avatarKind,reducedMotion:reducedMotion.matches,paused:paused||dialog.open||selectedView!=='field',
      onSelect:id=>{if(version===fieldVersion)selectCollection(id);},onHover:id=>{if(version===fieldVersion)highlightCollection(id);},
      onProject(points){if(version!==fieldVersion)return;const width=viewport.clientWidth,height=viewport.clientHeight;
        for(const point of points){const node=labelNodes[point.id];if(!node)continue;const x=Math.max(48,Math.min(width-48,point.x)),y=Math.max(0,Math.min(height-85,point.y));node.style.transform=`translate3d(${x}px,${y}px,0) translate(-50%,-8px)`;}
      },
      onTravel({id,progress,arrived}){
        if(version!==fieldVersion)return;if(id===null){pendingArrival=null;return;}if(id!==selectedId)return;
        $('#journey-line').style.transform=`scaleX(${Math.max(0,Math.min(1,progress))})`;if(!arrived)return;$('#journey-state').textContent=`${companions[avatarKind]} has arrived. Take your time.`;
        const arrival=pendingArrival;if(!arrival||arrival.id!==id)return;
        queueMicrotask(()=>{if(version!==fieldVersion||pendingArrival!==arrival||selectedId!==id||dialog.open)return;pendingArrival=null;openPanel(id,arrival.trigger?.isConnected?arrival.trigger:labelNodes[id]);});
      },
      onReady(){if(version!==fieldVersion||fieldFailed)return;document.documentElement.dataset.field='ready';$('#field-loading').hidden=true;labels.hidden=false;},
      onError(){if(version===fieldVersion)fieldUnavailable();},
    });
    if(version!==fieldVersion){created?.destroy();return;}field=created;if(!field){fieldUnavailable();return;}syncFieldMotion();
    if(selectedId&&activeIsland.landmarks.some(node=>node.collection===selectedId))field.travelTo(selectedId);
  }catch{if(version===fieldVersion)fieldUnavailable();}
}
function relatedLinks(item) {return item.related.length?`<nav class="dialog-related" aria-label="Related collections"><span>Related collections</span>${item.related.map(id=>`<a href="${escapeHTML(byId.get(id).url)}" data-collection="${id}">${escapeHTML(byId.get(id).title)} <span aria-hidden="true">↗</span></a>`).join('')}</nav>`:'';}
function collectionContent(item) {
  const children=pages.filter(page=>page.collection===item.id&&!page.parent);
  return `<div class="prose">${item.html}${children.length?'<h3>Pages in this collection</h3>'+children.map(pageLink).join(''):''}${item.projects.length?'<h3>Related projects</h3>'+item.projects.map(projectLink).join(''):''}</div>`;
}
function showReader(trigger,search=false) {
  if(!dialog.open){lastTrigger=trigger||document.activeElement;dialog.showModal();}document.body.classList.add('dialog-open');syncFieldMotion();dialog.scrollTop=0;
  if(search)$('#collection-search').focus();else $('#dialog-title').focus({preventScroll:true});
}
function openPanel(id,trigger) {
  const utility=id.startsWith('utility:')?id.slice(8):null;
  const item=utility?null:byId.get(id);if(!item&&!['about','search','archive'].includes(utility))return;pendingArrival=null;if(item&&selectedId!==id)selectCollection(id,{autoOpen:false});
  $('#dialog-category').textContent=item?`The archive / ${item.number}`:utility==='search'?'Search':utility==='archive'?'Archive':'About';
  if(item)dialogBody.innerHTML=`${draftLabel(item)}<h2 id="dialog-title" tabindex="-1">${escapeHTML(item.title)}</h2><p class="dialog-intro">${escapeHTML(item.description)}</p><a class="permalink" href="${escapeHTML(item.url)}">Open as a page <span aria-hidden="true">↗</span></a>${collectionContent(item)}${relatedLinks(item)}`;
  else if(utility==='archive')dialogBody.innerHTML=`<h2 id="dialog-title" tabindex="-1">Explore the archive.</h2><p class="dialog-intro">Collections from every island.</p>${collection.map(indexRow).join('')}`;
  else if(utility==='search'){
    dialogBody.innerHTML='<h2 id="dialog-title">Find your next stop.</h2><label class="sr-only" for="collection-search">Search collections, pages, and projects</label><input class="search-input" id="collection-search" type="search" placeholder="Try robotics, papers, or homes…" autocomplete="off"><p class="search-summary" id="search-summary" role="status"></p><div class="search-results" id="search-results"></div>';renderSearch('');
  }else dialogBody.innerHTML=`<h2 id="dialog-title" tabindex="-1">About ${escapeHTML(site.title)}.</h2>${site.about.split(/\n\s*\n/).map(text=>`<p class="reading-copy">${escapeHTML(text)}</p>`).join('')}`;
  showReader(trigger,utility==='search');
}
function openPage(id,trigger) {
  const page=pages.find(entry=>entry.id===id);if(!page)return;pendingArrival=null;
  const item=byId.get(page.collection),parents=[];let parent=page.parent;
  while(parent){const entry=pages.find(p=>p.id===parent);if(!entry)break;parents.unshift(entry);parent=entry.parent;}
  const children=pages.filter(entry=>entry.parent===id);$('#dialog-category').textContent=item.title;
  dialogBody.innerHTML=`<nav class="article-breadcrumbs" aria-label="Breadcrumb"><a href="${escapeHTML(item.url)}" data-collection="${item.id}">${escapeHTML(item.title)}</a>${parents.map(entry=>`<span aria-hidden="true">/</span><a href="${escapeHTML(entry.url)}" data-page="${entry.id}">${escapeHTML(entry.title)}</a>`).join('')}</nav>${draftLabel(page)}<h2 id="dialog-title" tabindex="-1">${escapeHTML(page.title)}</h2><p class="dialog-intro">${escapeHTML(page.description)}</p><a class="permalink" href="${escapeHTML(page.url)}">Open as a page <span aria-hidden="true">↗</span></a><div class="prose">${page.html}${children.length?'<h3>Subpages</h3>'+children.map(pageLink).join(''):''}</div>`;
  showReader(trigger);
}
function renderSearch(query) {
  const terms=query.toLowerCase().trim().split(/\s+/).filter(Boolean);
  const matches=item=>terms.every(term=>`${item.title} ${item.description} ${item.html.replace(/<[^>]+>/g,' ')} ${(item.projects||[]).map(id=>Object.values(projects[id]).join(' ')).join(' ')}`.toLowerCase().includes(term));
  const found=collection.filter(matches),foundPages=pages.filter(matches),count=found.length+foundPages.length;
  $('#search-summary').textContent=`${count} ${count===1?'result':'results'}${query.trim()?` matching “${query.trim()}”`:''}`;
  $('#search-results').innerHTML=count?found.map(indexRow).join('')+foundPages.map(pageLink).join(''):`<p class="empty-search">No results for “${escapeHTML(query.trim())}”. Try a broader word.</p>`;
}
document.addEventListener('click',event=>{
  const link=event.target.closest('a');
  if(link&&dialog.contains(link)&&!event.ctrlKey&&!event.metaKey&&!event.shiftKey&&!event.altKey){
    if(link.dataset.page){event.preventDefault();openPage(link.dataset.page,link);return;}
    if(link.dataset.collection){event.preventDefault();openPanel(link.dataset.collection,link);return;}
  }
  const button=event.target.closest('button');if(!button)return;
  if(button.dataset.select)selectCollection(button.dataset.select,{trigger:button});else if(button.dataset.open)openPanel(button.dataset.open,button);else if(button.dataset.view)setView(button.dataset.view);else if(button.classList.contains('dialog-close'))dialog.close();
});
islandSelect.addEventListener('change',()=>changeIsland(islandSelect.value));
$('#change-companion').addEventListener('click',()=>{const others=avatarKeys.filter(key=>key!==avatarKind);setCompanion(others[Math.floor(Math.random()*others.length)],true);});
$('#reset-view').addEventListener('click',()=>field?.resetCamera());
$('#motion-control').addEventListener('click',()=>{paused=!paused;try{localStorage.setItem('observatory-field-paused',String(paused));}catch{}syncFieldMotion();});
document.addEventListener('input',event=>{if(event.target.id==='collection-search')renderSearch(event.target.value);});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'&&dialog.open){event.preventDefault();dialog.close();return;}
  if(event.key==='Tab'&&dialog.open){const controls=[...dialog.querySelectorAll('a[href],button,input,[tabindex]:not([tabindex="-1"])')].filter(c=>!c.disabled&&c.getClientRects().length),first=controls[0],last=controls[controls.length-1];
    if(event.shiftKey&&(document.activeElement===first||!dialog.contains(document.activeElement))){event.preventDefault();last?.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}}
  const active=document.activeElement,typing=/INPUT|TEXTAREA|SELECT/.test(active.tagName)||active.isContentEditable;
  if(event.key==='/'&&!typing&&!event.ctrlKey&&!event.metaKey&&!event.altKey&&!dialog.open){event.preventDefault();openPanel('utility:search',$('.search-trigger'));}
});
dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();});
dialog.addEventListener('close',()=>{document.body.classList.remove('dialog-open');syncFieldMotion();if(lastTrigger?.isConnected&&(document.activeElement===document.body||dialog.contains(document.activeElement)))lastTrigger.focus({preventScroll:true});});
reducedMotion.addEventListener('change',syncFieldMotion);
window.addEventListener('pagehide',event=>{if(!event.persisted){fieldVersion++;field?.destroy();}});
renderMapControls();setCompanion(avatarKind);syncFieldMotion();$('#open-selection').dataset.open=islandItems()[0].id;
requestAnimationFrame(()=>setTimeout(startField,0));
